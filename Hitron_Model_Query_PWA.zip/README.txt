Hitron Model Query PWA
=======================
這是可安裝到 iPhone 主畫面的 PWA。

部署方式：
1. 將整個資料夾內容上傳到任何 HTTPS 靜態網站空間。
2. iPhone 用 Safari 開啟該網址。
3. 點 Safari 分享 -> 加入主畫面。
4. App 名稱會顯示為 Hitron Model。

注意：PWA 必須透過 HTTPS 網址開啟；不能直接從 ZIP 或 file:// 安裝。
